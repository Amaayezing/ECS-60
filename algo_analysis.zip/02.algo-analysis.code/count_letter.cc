#include <iostream>
#include <vector>

int count_letter(const std::string &str,
				 const char letter)
{
	int count = 0;

	for (auto c : str)
		if (c == letter)
			count++;

	return count;
}

int main(int argc, char *argv[])
{
	char letter = std::string(argv[1]).at(0);
	std::string str = argv[2];

	std::cout << "Number of '" << letter
		<< "' is " << count_letter(str, letter)
		<< std::endl;

	return 0;
}
