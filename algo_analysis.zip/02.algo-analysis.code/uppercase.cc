#include <iostream>
#include <vector>

std::string str_uppercase(const std::string &input)
{
	std::string output = input;

	for (auto &c : output)
		c = std::toupper(static_cast<unsigned char>(c));

	return output;
}

int main(int argc, char *argv[])
{
	std::string str = argv[1];
	std::string upp = str_uppercase(str);

	std::cout << "Uppercase string is '" << upp << "'"
		<< std::endl;

	return 0;
}
