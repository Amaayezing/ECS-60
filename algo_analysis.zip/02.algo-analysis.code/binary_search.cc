#include <iostream>
#include <vector>

int bsearch(std::vector<int> &array,
			int key)
{
	int lo = 0, hi = array.size() - 1;

	while (lo <= hi) {
		int mid = lo + (hi - lo) / 2;

		if (array[mid] == key)
			return mid;

		if (array[mid] < key)
			lo = mid + 1;
		else
			hi = mid - 1;
	}

	return -1;
}

int main(int argc, char *argv[])
{
	std::vector<int> haystack = {2, 3, 4, 10, 40};
	int needle = std::stol(argv[1]);
	int idx = bsearch(haystack, needle);

	if (idx == -1)
		std::cout << "Not found!" << std::endl;
	else
		std::cout << "Found at index " << idx << std::endl;

	return 0;
}
