/*
 * 3-SUM: Count the number of triplets which sum is zero in a set of integers
 */

#include <iostream>
#include <vector>

int count_3sum(std::vector<int> &a)
{
	int N = a.size();
	int count = 0;

	for (int i = 0; i < N; i++)
		for (int j = i + 1; j < N; j++)
			for (int k = j + 1; k < N; k++)
				if (a[i] + a[j] + a[k] == 0)
					count++;

	return count;
}

int main(void)
{
	std::vector<int> a;
	int n;

	while (std::cin >> n)
		a.push_back(n);

	std::cout << "Number of triplets: "
		<< count_3sum(a) << std::endl;

	return 0;
}

