/*
 * 1-SUM: Count the number of elements which value is zero in a set of integers
 */

#include <iostream>
#include <vector>

int count_1sum(std::vector<int> &a)
{
	int N = a.size();
	int count = 0;

	for (int i = 0; i < N; i++)
		if (a[i] == 0)
			count++;

	return count;
}

int main(void)
{
	std::vector<int> a;
	int n;

	while (std::cin >> n)
		a.push_back(n);

	std::cout << "Number of elements: "
		<< count_1sum(a) << std::endl;

	return 0;
}

