#include <iostream>
#include <vector>

// Generic insertion sort function
template<typename K>
void insertion_sort(std::vector<K> &a) {
  // N phases, from 0 to N-1
  for (unsigned i = 0; i < a.size(); i++) {
    // Swap current item with already sorted items
    // until finding its correct position
    for (int j = i ; j > 0; j--)
      if (a[j] < a[j-1])
        std::swap(a[j], a[j-1]);
      else
        break;
  }
}

int main(void) {
  // Vector of unordered integer numbers
  std::vector<int> vecint = {
    74, 98, 83, 52, 66, 64, 75, 8, 1, 69
  };

  // Print before sorting
  std::cout << "Before :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  // Sort vector
  insertion_sort<int>(vecint);

  // Print after sorting
  std::cout << "After :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  return 0;
}
