#include <iostream>
#include <vector>

// Generic insertion sort function
template<typename K>
void insertion_sort(std::vector<K> &a) {
  // N phases, from 0 to N-1
  for (unsigned i = 0; i < a.size(); i++) {
    // Swap current item with already sorted items
    // until finding its correct position
    for (int j = i ; j > 0; j--)
      if (a[j] < a[j-1])
        std::swap(a[j], a[j-1]);
      else
        break;
  }
}

// Bucket sort for int between 00 and 99
void bucket_sort(std::vector<int> &a) {
  // One bucket for each tens
  std::vector<std::vector<int>> bckts(10);
  // Scatter items in buckets
  for (auto &i : a) {
    // Extract tens digit from item
    int bi = (i / 10) % 10;
    // Put item into corresponding bucket
    bckts[bi].push_back(i);
  }
  // Sort each bucket separately
  for (auto &b : bckts)
    insertion_sort(b);
  // Combine all buckets back together
  int k = 0;
  for (auto &b : bckts)
    for (auto &i : b)
      a[k++] = i;
}

int main(void) {
  // Vector of unordered integer numbers
  std::vector<int> vecint = {
    74, 98, 83, 52, 66, 64, 75, 8, 1, 69
  };

  // Print before sorting
  std::cout << "Before :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  // Sort vector
  insertion_sort<int>(vecint);

  // Print after sorting
  std::cout << "After :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  return 0;
}
