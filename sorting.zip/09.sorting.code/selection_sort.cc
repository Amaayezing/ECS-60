#include <iostream>
#include <vector>

// Generic selection sort function
template<typename K>
void selection_sort(std::vector<K> &a) {
  // N phases, from 0 to N-1
  for (unsigned i = 0; i < a.size(); i++) {
    // Assume the minimum is the first element of the remaining collection
    unsigned min = i;

    // Look for a better minimum in remaining collection if any
    for (unsigned j = i + 1; j < a.size(); j++)
      if (a[j] < a[min])
        min = j;

    // Swap minimum with current element
    if (min != i)
      std::swap(a[min], a[i]);
  }
}

int main(void) {
  // Vector of unordered integer numbers
  std::vector<int> vecint = {
    74, 98, 83, 52, 66, 64, 75, 8, 1, 69
  };

  // Print before sorting
  std::cout << "Before :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  // Sort vector
  selection_sort<int>(vecint);

  // Print after sorting
  std::cout << "After :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  return 0;
}
