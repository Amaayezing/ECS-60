#include <iostream>
#include <vector>

// Helper functions
unsigned int Root() { return 0; }
unsigned int Parent(unsigned int i) { return (i - 1) / 2; }
unsigned int LeftChild(unsigned int i) { return 2 * i + 1; }
unsigned int RightChild(unsigned int i) { return 2 * i + 2; }
bool HasParent(unsigned int i) { return i != Root(); }
bool IsNode(unsigned int i, unsigned int max) { return i < max; }

// Heap restructuring
template <typename K>
void PercolateUp(std::vector<K> &a, unsigned int i) {
  while (HasParent(i) && a[Parent(i)] > a[i]) {
    std::swap(a[Parent(i)], a[i]);
    i = Parent(i);
  }
}

template <typename K>
void PercolateDown(std::vector<K> &a, unsigned int i) {
  // While node has at least one child (if one, necessarily on the left)
  while (IsNode(LeftChild(i), a.size())) {
    // Find smallest children between left and right if any
    unsigned int child = LeftChild(i);
    if (IsNode(RightChild(i), a.size()) && a[RightChild(i)] < a[LeftChild(i)])
      child = RightChild(i);

    // Exchange with node to restore heap-order if necessary
    if (a[child] < a[i])
      std::swap(a[child], a[i]);
    else
      break;

    // Do it again, one level down
    i = child;
  }
}

template <typename K>
void BuildHeap(std::vector<K> &a) {
  // Enforce heap-property on vector
  for (int i = a.size() / 2; i >= 0; i--)
    PercolateDown(a, i);
}

template <typename K>
K& Top(std::vector<K> &a) {
  return a[Root()];
}

template <typename K>
void Pop(std::vector<K> &a) {
  // Move last item back to root and reduce heap's size
  a[Root()] = std::move(a[a.size() - 1]);
  a.pop_back();
  PercolateDown(a, Root());
}

// Generic heapsort function based on min-heap
template <typename K>
void heapsort(std::vector<K> &a) {
  // Make a vector copy for the heap
  std::vector<K> a_heap(a);
  // Heapify
  BuildHeap(a_heap);
  // Extract min values in order
  for (unsigned i = 0; i < a.size(); i++) {
    a[i] = Top(a_heap);
    Pop(a_heap);
  }
}

int main(void) {
  // Vector of unordered integer numbers
  std::vector<int> vecint = {
    74, 98, 83, 52, 66, 64, 75, 8, 1, 69
  };

  // Print before sorting
  std::cout << "Before :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  // Sort vector
  heapsort<int>(vecint);

  // Print after sorting
  std::cout << "After :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  return 0;
}
