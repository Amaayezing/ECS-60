#include <iostream>
#include <vector>

template<typename K>
int quicksort_partition(std::vector<K> &a,
                        int lo, int hi) {
  int i = lo, j = hi + 1;
  while (true) {
    // From left to right, find first item
    // larger than pivot
    while (a[++i] < a[lo])
      // Prevents from going out of bounds
      if (i == hi) break;

    // From right to left, find first item
    // smaller than pivot
    while (a[lo] < a[--j])
      // To keep code symmetry but unnecessary
      if (j == lo) break;

    // If pointers i and j have crossed, stop
    if (i >= j) break;
    // Otherwise swap items
    std::swap(a[i], a[j]);
  }

  // Put pivot in final position
  std::swap(a[lo], a[j]);
  // Return pivot position
  return j;
}

template<typename K>
void quicksort_recur(std::vector<K> &a,
                     int lo, int hi) {
  // Recursion stop condition:
  // Sub-array is sorted if it contains 0 or 1 item
  if (hi <= lo)
    return;

  // Partition array and get resulting pivot pos
  int p = quicksort_partition(a, lo, hi);
  // Recursively sort left sub-partition
  quicksort_recur(a, lo, p - 1);
  // Recursively sort right sub-partition
  quicksort_recur(a, p + 1, hi);
}

// Generic quicksort function
template<typename K>
void quicksort(std::vector<K> &a) {
  quicksort_recur(a, 0, a.size() - 1);
}

int main(void) {
  // Vector of unordered integer numbers
  std::vector<int> vecint = {
    74, 98, 83, 52, 66,
    64, 75, 8, 1, 69
  };

  // Print before sorting
  std::cout << "Before :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  // Sort vector
  quicksort<int>(vecint);

  // Print after sorting
  std::cout << "After :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  return 0;
}
