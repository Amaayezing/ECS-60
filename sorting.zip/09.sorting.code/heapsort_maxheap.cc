#include <algorithm>
#include <iostream>
#include <vector>

// Generic heapsort function based on max-heap
template <typename K>
void heapsort(std::vector<K> &a) {
  // Heapify vector
  std::make_heap(a.begin(), a.end());
  // Pop max values in order
  for (unsigned i = 0; i < a.size(); i++)
    std::pop_heap(a.begin(), a.end() - i);
}

int main(void) {
  // Vector of unordered integer numbers
  std::vector<int> vecint = {
    74, 98, 83, 52, 66, 64, 75, 8, 1, 69
  };

  // Print before sorting
  std::cout << "Before :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  // Sort vector
  heapsort<int>(vecint);

  // Print after sorting
  std::cout << "After :";
  for (auto &i : vecint)
    std::cout << " " << i;
  std::cout << std::endl;

  return 0;
}
