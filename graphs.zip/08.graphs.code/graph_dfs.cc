#include <fstream>
#include <list>
#include <string>

#include "graph_adjacency_lists.h"

class DepthFirstPaths {
 public:
  // Find paths in @G from vertex @s
  DepthFirstPaths(Graph G, int s);
  // Return true if path from s to @v
  bool HasPathTo(int v);
  // Return path from s to @v, if any
  std::list<int> PathTo(int v);

 private:
  std::vector<bool> marked;
  std::vector<int> edg_to;
  int s;

  // Recursive depth-first search
  void dfs(Graph G, int v);
};

DepthFirstPaths::DepthFirstPaths(Graph G, int s)
  : marked(G.V(), false),
    edg_to(G.V(), -1), s(s) {
  dfs(G, s);
}

void DepthFirstPaths::dfs(Graph G, int v) {
  marked[v] = true;
  for (auto &w : G.Adj(v)) {
    if (!marked[w]) {
      dfs(G, w);
      edg_to[w] = v;
    }
  }
}

bool DepthFirstPaths::HasPathTo(int v) {
  return marked[v];
}

std::list<int> DepthFirstPaths::PathTo(int v) {
  std::list<int> path;

  if (HasPathTo(v)) {
    for (int w = v; w != s; w = edg_to[w])
      path.push_front(w);
    path.push_front(s);
  }
  return path;
}

int main(int argc, char *argv[]) {
  if (argc != 3) {
    std::cerr << "Usage: " << argv[0] << " <graph.txt> <s>" << std::endl;
    return 1;
  }

  std::ifstream ifs(argv[1]);
  int s = std::stoi(argv[2]);

  Graph G(ifs);
  DepthFirstPaths dfp(G, s);

  for (int v = 0; v < G.V(); v++) {
    std::cout << v << ": ";
    if (dfp.HasPathTo(v))
      for (auto &w : dfp.PathTo(v))
        std::cout << w << ", ";
    else
      std::cout << "no path";
    std::cout << std::endl;
  }

  return 0;
}
