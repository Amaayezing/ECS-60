#ifndef GRAPH_ADJACENCY_MATRIX_H_
#define GRAPH_ADJACENCY_MATRIX_H_

#include <fstream>
#include <iostream>
#include <utility>
#include <vector>

class Graph {
  // Generic Graph API
 public:
  // Create empty graph with V vertices
  Graph(int V);
  // Create graph from input stream
  Graph(std::ifstream &ifs);
  // Add an edge v-w
  void AddEdge(int v, int w);
  // Vertices adjacent to v
  std::vector<int> Adj(int v);
  // Number of vertices
  int V();
  // Number of edges
  int E();

 private:
  // Adjacency matrix implementation
  std::vector<std::vector<bool>> adj_m;
  int nv;
  int ne = 0;
};

Graph::Graph(int V) :
    adj_m(V, std::vector<bool>(V, false)),
    nv(V) {}

Graph::Graph(std::ifstream &ifs) {
  // Get number of vertices
  ifs >> nv;

  // Allocate 2-D matrix
  adj_m.resize(nv, std::vector<bool>(nv, false));

  // Go through all the edges and add them
  int v, w;
  while (ifs >> v >> w)
    AddEdge(v, w);
}

void Graph::AddEdge(int v, int w) {
  adj_m[v][w] = true;
  adj_m[w][v] = true;
  ++ne;
}

std::vector<int> Graph::Adj(int v) {
  std::vector<int> v_edges;

  for (int w = 0; w < V(); w++) {
    if (adj_m[v][w])
      v_edges.push_back(w);
  }

  return v_edges;
}

int Graph::V() { return nv; }
int Graph::E() { return ne; }

#endif  // GRAPH_ADJACENCY_MATRIX_H_
