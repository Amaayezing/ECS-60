#include <fstream>

#include "graph_adjacency_lists.h"

int main(int argc, char *argv[]) {
  if (argc != 2) {
    std::cerr << "Usage: " << argv[0] << " <graph.txt>" << std::endl;
    return 1;
  }

  std::ifstream ifs(argv[1]);
  Graph G(ifs);

  for (int v = 0; v < G.V(); v++)
    for (auto &w : G.Adj(v))
      std::cout << v << " - " << w << std::endl;

  return 0;
}
