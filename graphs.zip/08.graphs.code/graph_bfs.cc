#include <fstream>
#include <list>
#include <queue>
#include <string>

#include "graph_adjacency_lists.h"

class BreadthFirstPaths {
 public:
  // Find paths in @G from source vertex @s
  BreadthFirstPaths(Graph G, int s);
  // Return whether there is a path from s to @v
  bool HasPathTo(int v);
  // Return path from s to @v, if any
  std::list<int> PathTo(int v);

 private:
  std::vector<bool> marked;
  std::vector<int> edg_to;
  int s;

  // Iterative breadth-first search
  void bfs(Graph G, int s);
};

BreadthFirstPaths::BreadthFirstPaths(Graph G, int s)
  : marked(G.V(), false),
    edg_to(G.V(), -1), s(s) {
  bfs(G, s);
}

void BreadthFirstPaths::bfs(Graph G, int s) {
  std::queue<int> q;

  q.push(s);
  marked[s] = true;
  while (!q.empty()) {
    int v = q.front(); q.pop();
    for (auto &w : G.Adj(v)) {
      if (!marked[w]) {
        q.push(w);
        marked[w] = true;
        edg_to[w] = v;
      }
    }
  }
}

bool BreadthFirstPaths::HasPathTo(int v) {
  return marked[v];
}

std::list<int> BreadthFirstPaths::PathTo(int v) {
  std::list<int> path;

  if (HasPathTo(v)) {
    for (int w = v; w != s; w = edg_to[w])
      path.push_front(w);
    path.push_front(s);
  }
  return path;
}

int main(int argc, char *argv[]) {
  if (argc != 3) {
    std::cerr << "Usage: " << argv[0] << " <graph.txt> <s>" << std::endl;
    return 1;
  }

  std::ifstream ifs(argv[1]);
  int s = std::stoi(argv[2]);

  Graph G(ifs);
  BreadthFirstPaths dfp(G, s);

  for (int v = 0; v < G.V(); v++) {
    std::cout << v << ": ";
    if (dfp.HasPathTo(v)) {
      for (auto &w : dfp.PathTo(v))
        std::cout << w << ", ";
      std::cout << std::endl;
    } else {
      std::cout << "no path" << std::endl;
    }
  }

  return 0;
}
