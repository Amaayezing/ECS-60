#ifndef GRAPH_EDGES_LIST_H_
#define GRAPH_EDGES_LIST_H_

#include <fstream>
#include <iostream>
#include <utility>
#include <vector>

class Graph {
  // Generic Graph API
 public:
  // Create empty graph with V vertices
  Graph(int V);
  // Create graph from input stream
  Graph(std::ifstream &ifs);
  // Add an edge v-w
  void AddEdge(int v, int w);
  // Vertices adjacent to v
  std::vector<int> Adj(int v);
  // Number of vertices
  int V();
  // Number of edges
  int E();

 private:
  // Edge list implementation
  std::vector<std::pair<int, int>> edges;
  int nv;
};

Graph::Graph(int V) : nv(V) {}

Graph::Graph(std::ifstream &ifs) {
  // Get number of vertices
  ifs >> nv;

  // Go through all the edges and add them
  int v, w;
  while (ifs >> v >> w)
    AddEdge(v, w);
}

void Graph::AddEdge(int v, int w) {
  edges.emplace_back(std::make_pair(v, w));
}

std::vector<int> Graph::Adj(int v) {
  std::vector<int> v_edges;

  for (auto &e : edges) {
    if (e.first == v)
      v_edges.push_back(e.second);
    else if (e.second == v)
      v_edges.push_back(e.first);
  }

  return v_edges;
}

int Graph::V() { return nv; }
int Graph::E() { return edges.size(); }

#endif  // GRAPH_EDGES_LIST_H_
