#ifndef AVL_H_
#define AVL_H_

#include <memory>
#include <utility>

template <typename T>
class AVL {
 public:
  // Return whether @key is found in tree
  bool Contains(const T& key);
  // Return max key in tree
  const T& Max();
  // Return min key in tree
  const T& Min();
  // Insert @key in tree
  void Insert(const T &key);
  // Remove @key from tree
  void Remove(const T &key);
  // Print tree in-order
  void Print();

 private:
  struct Node{
    T key;
    int height;
    std::unique_ptr<Node> left;
    std::unique_ptr<Node> right;
  };
  std::unique_ptr<Node> root;

  // Recursive helper methods
  Node* Min(Node *n);
  void Insert(std::unique_ptr<Node> &n, const T &key);
  void Remove(std::unique_ptr<Node> &n, const T &key);
  void Print(Node *n, int level);

  // Helper methods for the self-balancing
  int Height(Node *n);
  void RotateRight(std::unique_ptr<Node> &prt);
  void RotateLeft(std::unique_ptr<Node> &prt);
  void Retrace(std::unique_ptr<Node> &n);
};

template <typename T>
bool AVL<T>::Contains(const T &key) {
  Node *n = root.get();

  while (n) {
    if (key == n->key)
      return true;

    if (key < n->key)
      n = n->left.get();
    else
      n = n->right.get();
  }

  return false;
}

template <typename T>
const T& AVL<T>::Max(void) {
  Node *n = root.get();
  while (n->right) n = n->right.get();
  return n->key;
}

template <typename T>
const T& AVL<T>::Min(void) {
  return Min(root.get())->key;
}

template <typename T>
typename AVL<T>::Node* AVL<T>::Min(Node *n) {
  if (n->left)
    return Min(n->left.get());
  else
    return n;
}

template <typename T>
int AVL<T>::Height(Node *n) {
  if (!n) return -1;
  return n->height;
}

template <typename T>
void AVL<T>::RotateRight(std::unique_ptr<Node> &prt) {
  std::unique_ptr<Node> chd = std::move(prt->left);
  prt->left = std::move(chd->right);
  prt->height = 1 + std::max(Height(prt->left.get()), Height(prt->right.get()));
  chd->right = std::move(prt);
  chd->height = 1 + std::max(Height(chd->left.get()), Height(chd->right.get()));
  prt = std::move(chd);
}

template <typename T>
void AVL<T>::RotateLeft(std::unique_ptr<Node> &prt) {
  std::unique_ptr<Node> chd = std::move(prt->right);
  prt->right = std::move(chd->left);
  prt->height = 1 + std::max(Height(prt->right.get()), Height(prt->left.get()));
  chd->left = std::move(prt);
  chd->height = 1 + std::max(Height(chd->right.get()), Height(chd->left.get()));
  prt = std::move(chd);
}

template <typename T>
void AVL<T>::Retrace(std::unique_ptr<Node> &n) {
  if (!n) return;

  if (Height(n->left.get()) - Height(n->right.get()) > 1) {
    // Tree is left heavy: need rebalancing

    if (Height(n->left->left.get()) < Height(n->left->right.get()))
      // Left subtree is right heavy: need double rotation
      RotateLeft(n->left);

    RotateRight(n);

  } else if (Height(n->right.get()) - Height(n->left.get()) > 1) {
    // Tree is right heavy: need rebalancing

    if (Height(n->right->right.get()) < Height(n->right->left.get()))
      // Right subtree is left heavy: need double rotation
      RotateRight(n->right);

    RotateLeft(n);
  }

  // Adjust node's height
  n->height = 1 + std::max(Height(n->left.get()), Height(n->right.get()));
}

template <typename T>
void AVL<T>::Insert(const T &key) {
  Insert(root, key);
}

template <typename T>
void AVL<T>::Insert(std::unique_ptr<Node> &n, const T &key) {
  if (!n)
    n = std::unique_ptr<Node>(new Node{key});
  else if (key < n->key)
    Insert(n->left, key);
  else if (key > n->key)
    Insert(n->right, key);
  else
    std::cerr << "Key " << key << " already inserted!\n";

  Retrace(n);
}

template <typename T>
void AVL<T>::Remove(const T &key) {
  Remove(root, key);
}

template <typename T>
void AVL<T>::Remove(std::unique_ptr<Node> &n, const T &key) {
  // Key not found
  if (!n) return;

  if (key < n->key) {
    Remove(n->left, key);
  } else if (key > n->key) {
    Remove(n->right, key);
  } else {
    // Found node
    if (n->left && n->right) {
      // Two children: replace with min node in right subtree
      n->key = Min(n->right.get())->key;
      Remove(n->right, n->key);
    } else {
      // Replace with only child or with nullptr
      n = std::move((n->left) ? n->left : n->right);
    }
  }

  Retrace(n);
}

template <typename T>
void AVL<T>::Print() {
  Print(root.get(), 1);
  std::cout << std::endl;
}

template <typename T>
void AVL<T>::Print(Node *n, int level) {
  if (!n) return;

  Print(n->left.get(), level + 1);
  std::cout << n->key
      << " (" << level << ") ";
  Print(n->right.get(), level + 1);
}

#endif  // AVL_H_
