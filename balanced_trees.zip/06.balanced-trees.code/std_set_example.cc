#include <iostream>
#include <set>

int main() {
  // Initialization
  std::set<int> s = {7, 5, 16, 8};

  // Add item dynamically
  s.insert(6);

  // Add already existing item
  s.insert(8);

  // Iterate and print values
  for (auto n : s)
    std::cout << n << std::endl;

  return 0;
}
