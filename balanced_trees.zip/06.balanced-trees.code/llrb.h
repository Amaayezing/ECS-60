#ifndef LLRB_H_
#define LLRB_H_

#include <iostream>
#include <memory>
#include <string>
#include <utility>

// Left-Leaning Red-Black tree implementation
template <typename T>
class LLRB {
 public:
  // Return whether @key is found in tree
  bool Contains(const T& key);
  // Return max key in tree
  const T& Max();
  // Return min key in tree
  const T& Min();
  // Insert @key in tree
  void Insert(const T &key);
  // Print tree in-order
  void Print();

 private:
  enum Color : bool { RED, BLACK };
  struct Node{
    T key;
    Color color;
    std::unique_ptr<Node> left;
    std::unique_ptr<Node> right;
  };
  std::unique_ptr<Node> root;

  // Recursive helper methods
  Node* Min(Node *n);
  void Insert(std::unique_ptr<Node> &n, const T &key);
  void Print(Node *n, int level);

  // Helper methods for the self-balancing
  bool IsRed(Node *n);
  void Recolor(Node *n);
  void RotateRight(std::unique_ptr<Node> &prt);
  void RotateLeft(std::unique_ptr<Node> &prt);
};

template <typename T>
bool LLRB<T>::Contains(const T &key) {
  Node *n = root.get();

  while (n) {
    if (key == n->key)
      return true;

    if (key < n->key)
      n = n->left.get();
    else
      n = n->right.get();
  }

  return false;
}

template <typename T>
const T& LLRB<T>::Max(void) {
  Node *n = root.get();
  while (n->right) n = n->right.get();
  return n->key;
}

template <typename T>
const T& LLRB<T>::Min(void) {
  return Min(root.get())->key;
}

template <typename T>
typename LLRB<T>::Node* LLRB<T>::Min(Node *n) {
  if (n->left)
    return min(n->left.get());
  else
    return n;
}

template <typename T>
bool LLRB<T>::IsRed(Node *n) {
  if (!n) return false;
  return (n->color == RED);
}

template <typename T>
void LLRB<T>::Recolor(Node *n) {
  n->color = RED;
  n->left->color = BLACK;
  n->right->color = BLACK;
}

template <typename T>
void LLRB<T>::RotateRight(std::unique_ptr<Node> &prt) {
  std::unique_ptr<Node> chd = std::move(prt->left);
  prt->left = std::move(chd->right);
  chd->color = prt->color;
  prt->color = RED;
  chd->right = std::move(prt);
  prt = std::move(chd);
}

template <typename T>
void LLRB<T>::RotateLeft(std::unique_ptr<Node> &prt) {
  std::unique_ptr<Node> chd = std::move(prt->right);
  prt->right = std::move(chd->left);
  chd->color = prt->color;
  prt->color = RED;
  chd->left = std::move(prt);
  prt = std::move(chd);
}

template <typename T>
void LLRB<T>::Insert(const T &key) {
  Insert(root, key);
  root->color = BLACK;
}

template <typename T>
void LLRB<T>::Insert(std::unique_ptr<Node> &n, const T &key) {
  if (!n)
    n = std::unique_ptr<Node>(new Node{key, RED});
  else if (key < n->key)
    Insert(n->left, key);
  else if (key > n->key)
    Insert(n->right, key);
  else
    std::cerr << "Key " << key << " already inserted!\n";

  if (IsRed(n->right.get()) && !IsRed(n->left.get()))
    RotateLeft(n);
  if (IsRed(n->left.get()) && IsRed(n->left->left.get()))
    RotateRight(n);
  if (IsRed(n->left.get()) && IsRed(n->right.get()))
    Recolor(n.get());
}

template <typename T>
void LLRB<T>::Print() {
  Print(root.get(), 1);
  std::cout << std::endl;
}

template <typename T>
void LLRB<T>::Print(Node *n, int level) {
  if (!n) return;
  static const std::string colors[] = { "R", "B" };

  Print(n->left.get(), level + 1);
  std::cout << n->key
      << " (" << level << " - "
      << colors[n->color] << ") ";
  Print(n->right.get(), level + 1);
}

#endif  // LLRB_H_
