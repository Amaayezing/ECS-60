#include <vector>

#include "llrb.h"

// Tester
int main() {
  std::vector<int> keys{2, 18, 42, 43, 51, 54, 74, 93, 99};

  LLRB<int> llrb;
  for (auto i : keys) {
    llrb.Insert(i);
    llrb.Print();
  }

  return 0;
}
