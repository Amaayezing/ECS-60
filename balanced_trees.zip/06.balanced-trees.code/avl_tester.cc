#include <algorithm>
#include <iostream>
#include <random>
#include <vector>

#include "avl.h"

// Tester

int main() {
  std::vector<int> keys{2, 18, 42, 43, 51, 54, 74, 93, 99};

  AVL<int> avl;
  for (auto i : keys) {
    avl.Insert(i);
    avl.Print();
  }

  // Alternate insertions and deletions

  // Create random number generator with seed 0
  std::mt19937 rng(0);
  // Create uniform distribution of numbers
  std::uniform_int_distribution<int> distr(0, 99);

  // Insert and delete 100 times
  for (int i = 0; i < 100 ; i++) {
    // Insert random key that is not already in AVL
    int rval;
    do {
      rval = distr(rng);
    } while (avl.Contains(rval));
    avl.Insert(rval);
    keys.push_back(rval);

    // Remove existing random key from the AVL
    std::shuffle(keys.begin(), keys.end(), rng);
    avl.Remove(keys.back());
    keys.pop_back();
  }

  // AVL should still be balanced
  avl.Print();

  return 0;
}
