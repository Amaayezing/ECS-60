#include <iostream>
#include <map>

int main() {
  // Initialization
  std::map<int, std::string> m = {
    {36, "Alice"}, {23, "Bob"}
  };

  // Dynamic insertion by indexing
  m[8] = "Lisa";

  // Dynamic pair insertion
  m.insert({10, "Bart"});

  // Alternative pair insertion
  // and of duplicated item
  m.insert(std::make_pair(10, "Bart"));

  // Iterate and print values
  for (auto n : m)
    std::cout << "(" << n.second
        << ": " << n.first << ")"
        << std::endl;

  return 0;
}
