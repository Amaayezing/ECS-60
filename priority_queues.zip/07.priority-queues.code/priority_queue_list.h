#ifndef PRIORITY_QUEUE_H_
#define PRIORITY_QUEUE_H_

#include <algorithm>
#include <list>

template <typename T>
class PriorityQueue {
 public:
  // Return number of items in priority queue
  unsigned int Size();
  // Return top of priority queue
  T& Top();
  // Remove top of priority queue
  void Pop();
  // Insert item and sort priority queue
  void Push(const T &item);

 private:
  std::list<T> items;
};

template <typename T>
unsigned int PriorityQueue<T>::Size() {
  return items.size();
}

template <typename T>
T& PriorityQueue<T>::Top(void) {
  if (!Size())
    throw std::underflow_error(
        "Empty priority queue!");
  return items.front();
}

template <typename T>
void PriorityQueue<T>::Pop() {
  if (!Size())
    throw std::underflow_error(
        "Empty priority queue!");
  items.pop_front();
}

template <typename T>
void PriorityQueue<T>::Push(const T &item) {
  // Find first bigger element than @item
  auto pos = std::lower_bound(
      items.begin(), items.end(), item);
  // Insert before it
  items.insert(pos, item);
}

#endif  // PRIORITY_QUEUE_H_
