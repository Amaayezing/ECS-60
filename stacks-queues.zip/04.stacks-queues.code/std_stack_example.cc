#include <iostream>
#include <stack>
#include <string>

void check_balance(std::string &str) {
  enum { OPEN_SYMS, CLOS_SYMS, T_SYMS };
  static const std::string symbols[T_SYMS] = { "({[", ")}]" };
  std::stack<char> bal_stack;

  for (auto c : str) {
    if (symbols[OPEN_SYMS].find(c) != std::string::npos) {
      bal_stack.push(c);
    } else {
      auto which = symbols[CLOS_SYMS].find(c);
      if (which != std::string::npos) {
        if (!bal_stack.empty() &&
            bal_stack.top() == symbols[OPEN_SYMS][which]) {
          bal_stack.pop();
        } else {
          std::cerr << "Unbalanced string!" << std::endl;
          return;
        }
      }
    }
  }

  if (!bal_stack.empty())
    std::cerr << "Unbalanced string!" << std::endl;
}

int main(int argc, char *argv[]) {
  std::string str = argv[1];
  check_balance(str);
  return 0;
}
