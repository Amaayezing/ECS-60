#ifndef LIST_H
#define LIST_H

#include <memory>

template <typename T>
class List {
 public:
  List();
  ~List();

  /* Return number of items in list */
  int size();
  /* Return item at position @pos */
  const T& get(const int pos);
  /* Return position of first occurence of @item (-1 if not found) */
  int find(const T &item);
  /* Remove item at position @pos */
  void remove(const int pos);
  /* Insert @item at position @pos */
  void insert(const T &item, const int pos);

 private:
  /* Pimpl idiom: <https://herbsutter.com/gotw/_100/> */
  struct Impl;
  const std::unique_ptr<Impl> pimpl;
};

#endif /* LIST_H */
