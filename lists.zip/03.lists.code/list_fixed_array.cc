#include <gtest/gtest.h>

#include "list.h"

/*
 * Implementation of a List ADT using a fixed array data structure
 *
 * Note: because std::array is a regular container, we could use std::move() to
 * move the ranges around in remove() and insert() (e.g.
 * `std::move(pimpl->items.begin() + pos + 1, pimpl->items.begin() +
 * pimpl->cur_size, pimpl->items.begin() + pos);` in remove()).
 * We choose not to use std::move() though, in order to keep some symmetry
 * between this implementation and the dynamic array implementation which uses
 * C-style arrays encapsulated into smart pointers and doesn't have `.begin()`.
 */

template <typename T>
struct List<T>::Impl {
  static constexpr int capacity = 3;
  std::array<T, capacity> items;
  int cur_size = 0;
};

template <typename T>
List<T>::List() : pimpl(new Impl) {}

template <typename T>
List<T>::~List() = default;

template <typename T>
int List<T>::size() {
  return pimpl->cur_size;
}

template <typename T>
const T& List<T>::get(const int pos) {
  if (pos >= pimpl->cur_size)
    throw std::out_of_range("Position out of range!");

  return pimpl->items[pos];
}

template <typename T>
int List<T>::find(const T &item) {
  for (auto i = 0; i < pimpl->cur_size; i++)
    if (pimpl->items[i] == item)
      return i;
  return -1;
}

template <typename T>
void List<T>::remove(const int pos) {
  if (pos >= pimpl->cur_size)
    throw std::out_of_range("Position out of range!");

  for (auto i = pos + 1; i < pimpl->cur_size; i++)
    pimpl->items[i - 1] = pimpl->items[i];
  pimpl->cur_size--;
}

template <typename T>
void List<T>::insert(const T &item, const int pos) {
  if (pos > pimpl->cur_size)
    throw std::out_of_range("Position out of range!");
  if (pimpl->cur_size == pimpl->capacity)
    throw std::runtime_error("List full!");

  if (pos != pimpl->cur_size)
    /* Move existing item(s) if insertion before them */
    for (auto i = pimpl->cur_size - 1; i >= pos; i--)
      pimpl->items[i + 1] = pimpl->items[i];

  pimpl->items[pos] = item;
  pimpl->cur_size++;
}

/*
 * Testing
 */
TEST(List, List) {
  List<int> l;
  ASSERT_EQ(l.size(), 0);

  /* Test some exceptions */
  ASSERT_THROW(l.get(1), std::out_of_range);
  ASSERT_THROW(l.remove(0), std::out_of_range);
  ASSERT_THROW(l.insert(1, 1), std::out_of_range);

  /* Insert item */
  l.insert(23, 0);
  ASSERT_EQ(l.size(), 1);
  ASSERT_EQ(l.get(0), 23);

  /* Insert item at the back */
  l.insert(42, l.size());
  ASSERT_EQ(l.size(), 2);
  ASSERT_EQ(l.get(0), 23);
  ASSERT_EQ(l.get(1), 42);

  /* Insert item at the front */
  l.insert(99, 0);
  ASSERT_EQ(l.size(), 3);
  ASSERT_EQ(l.get(0), 99);
  ASSERT_EQ(l.get(1), 23);
  ASSERT_EQ(l.get(2), 42);

  /* Find values */
  ASSERT_EQ(l.find(42), 2);
  ASSERT_EQ(l.find(0), -1);

  /* Over capacity */
  ASSERT_THROW(l.insert(1, l.size()), std::runtime_error);

  /* Delete front */
  l.remove(0);
  ASSERT_EQ(l.size(), 2);
  ASSERT_EQ(l.get(0), 23);
  ASSERT_EQ(l.get(1), 42);

  /* Delete back */
  l.remove(1);
  ASSERT_EQ(l.size(), 1);
  ASSERT_EQ(l.get(0), 23);
}

int main(int argc, char *argv[]) {
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
